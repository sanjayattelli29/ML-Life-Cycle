# Make the directory a Python package
