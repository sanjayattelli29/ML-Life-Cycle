from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import numpy as np
import pandas as pd
try:
    from utils.metrics import calculate_clustering_metrics, get_model_performance_summary
    from utils.preprocessing import preprocess_data
except ImportError as e:
    print(f"Warning: Could not import utils modules: {e}")
    # Define fallback functions
    def calculate_clustering_metrics(X, labels):
        return {'silhouette_score': 0.0, 'calinski_harabasz_score': 0.0, 'davies_bouldin_score': 0.0}
    def get_model_performance_summary(metrics, task_type):
        return "Performance summary not available"
    def preprocess_data(df, features, target=None, preprocessing_steps=None):
        return df, None, None

def train_model(dataframe, features, hyperparams=None):
    """
    Train a K-Means clustering model
    
    Args:
        dataframe: Input pandas DataFrame
        features: List of feature column names
        hyperparams: Dictionary of hyperparameters
    
    Returns:
        Trained model, metrics
    """
    if hyperparams is None:
        hyperparams = {}
    
    # Set default hyperparameters
    default_params = {
        'n_clusters': 3,
        'init': 'k-means++',
        'n_init': 10,
        'max_iter': 300,
        'tol': 1e-4,
        'random_state': 42,
        'algorithm': 'lloyd'  # Changed from 'auto' to 'lloyd' for compatibility
    }
    
    # Update with provided hyperparameters
    default_params.update(hyperparams)
    
    # Validate and fix algorithm parameter for compatibility
    if 'algorithm' in default_params and default_params['algorithm'] == 'auto':
        default_params['algorithm'] = 'lloyd'  # Use 'lloyd' instead of deprecated 'auto'
    
    # Ensure algorithm is valid
    if 'algorithm' in default_params and default_params['algorithm'] not in ['lloyd', 'elkan']:
        default_params['algorithm'] = 'lloyd'
    
    # Preprocess data
    processed_df, feature_encoders, _ = preprocess_data(
        dataframe, features, target=None,
        preprocessing_steps={
            'handle_missing': True,
            'encode_categorical': True,
            'scale_features': True,  # K-means benefits from scaling
            'remove_outliers': False
        }
    )
    
    # Prepare features
    X = processed_df[features]
    
    # Ensure all data is numeric and handle any remaining issues
    for feature in features:
        if feature in X.columns:
            # Convert to numeric, coerce errors to NaN
            X[feature] = pd.to_numeric(X[feature], errors='coerce')
    
    # Fill any remaining NaN values
    X = X.fillna(X.mean())
    
    # Ensure we have enough data points
    if len(X) < 2:
        raise ValueError("Not enough data points for clustering. Need at least 2 samples.")
    
    # Auto-determine number of clusters if not specified
    if 'n_clusters' not in hyperparams:
        optimal_k = find_optimal_clusters(X, max_k=min(10, len(X)//2))
        default_params['n_clusters'] = optimal_k
    
    # Ensure n_clusters is not greater than number of samples
    default_params['n_clusters'] = min(default_params['n_clusters'], len(X) - 1)
    
    # Train the model
    try:
        model = KMeans(**default_params)
        cluster_labels = model.fit_predict(X)
    except Exception as e:
        raise ValueError(f"Failed to train KMeans model: {str(e)}")
    
    # Calculate metrics
    try:
        metrics = calculate_clustering_metrics(X.values if hasattr(X, 'values') else X, cluster_labels)
    except Exception as e:
        # Fallback metrics if calculation fails
        metrics = {
            'silhouette_score': 0.0,
            'calinski_harabasz_score': 0.0,
            'davies_bouldin_score': 0.0
        }
    
    # Add model-specific information
    metrics['model_type'] = 'kmeans'
    metrics['hyperparameters'] = default_params
    metrics['feature_count'] = len(features)
    metrics['total_samples'] = len(X)
    
    # Add K-means specific metrics
    metrics['inertia'] = float(model.inertia_)
    metrics['n_iter'] = int(model.n_iter_)
    
    # Add cluster centers
    if hasattr(model, 'cluster_centers_'):
        cluster_centers = {}
        for i, center in enumerate(model.cluster_centers_):
            cluster_centers[f'cluster_{i}'] = {
                feature: float(center[j]) for j, feature in enumerate(features)
            }
        metrics['cluster_centers'] = cluster_centers
    
    # Calculate within-cluster sum of squares for each cluster
    cluster_wcss = []
    for i in range(default_params['n_clusters']):
        cluster_points = X[cluster_labels == i]
        if len(cluster_points) > 0:
            center = model.cluster_centers_[i]
            # Convert to numpy array to avoid pandas Series issues
            cluster_points_array = cluster_points.values if hasattr(cluster_points, 'values') else cluster_points
            wcss = float(np.sum((cluster_points_array - center) ** 2))
            cluster_wcss.append(wcss)
        else:
            cluster_wcss.append(0.0)
    
    metrics['cluster_wcss'] = cluster_wcss
    
    # Add cluster assignments to dataframe (ALL samples for complete preview)
    # Changed from limiting to 100 samples to include all data points
    sample_size = len(X)  # Use all samples instead of limiting to 100
    cluster_preview = pd.DataFrame({
        'sample_index': range(sample_size),
        'cluster': cluster_labels.tolist()
    })
    
    # Add original feature values for preview (all features)
    for feature in features:  # Include all features, not just first 5
        if feature in X.columns:
            feature_values = X[feature]
            # Ensure we convert to list properly
            cluster_preview[feature] = [float(val) if pd.notna(val) and val is not None else 0.0 for val in feature_values]
    
    metrics['cluster_preview'] = cluster_preview.to_dict(orient='records')
    
    # Calculate cluster characteristics
    cluster_stats = {}
    for i in range(default_params['n_clusters']):
        cluster_mask = cluster_labels == i
        cluster_data = X[cluster_mask]
        
        if len(cluster_data) > 0:
            cluster_stats[f'cluster_{i}'] = {
                'size': int(len(cluster_data)),
                'percentage': float(len(cluster_data) / len(X) * 100),
                'feature_means': {
                    feature: float(cluster_data[feature].mean()) if feature in cluster_data.columns else 0.0
                    for feature in features
                },
                'feature_stds': {
                    feature: float(cluster_data[feature].std()) if feature in cluster_data.columns else 0.0
                    for feature in features
                }
            }
    
    metrics['cluster_statistics'] = cluster_stats
    
    # Add performance summary
    metrics['performance_summary'] = get_model_performance_summary(metrics, 'clustering')
    
    # Store preprocessing information
    metrics['preprocessing'] = {
        'feature_encoders': feature_encoders is not None,
        'scaled_features': True
    }
    
    return model, metrics

def find_optimal_clusters(X, max_k=10, method='elbow'):
    """
    Find optimal number of clusters using elbow method
    
    Args:
        X: Feature matrix
        max_k: Maximum number of clusters to test
        method: Method to use ('elbow')
    
    Returns:
        Optimal number of clusters
    """
    if len(X) < 4:
        return 2
    
    max_k = min(max_k, len(X) - 1, 10)  # Cap at 10 for performance
    if max_k < 2:
        return 2
        
    inertias = []
    
    try:
        for k in range(1, max_k + 1):
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=5, algorithm='lloyd')
            
            # Safely fit the model
            try:
                fit_params = {}
                kmeans.fit(X, **fit_params)
            except TypeError as e:
                # If any parameter is not supported, try without additional parameters
                print(f"⚠️ KMeans fit with parameters failed: {str(e)}")
                print("   Falling back to standard fit...")
                kmeans.fit(X)
            inertias.append(kmeans.inertia_)
        
        # Find elbow using rate of change
        if len(inertias) >= 3:
            diffs = np.diff(inertias)
            # Avoid division by zero
            diff_ratios = []
            for i in range(len(diffs) - 1):
                if diffs[i+1] != 0:
                    diff_ratios.append(diffs[i] / diffs[i+1])
                else:
                    diff_ratios.append(0)
            
            if diff_ratios:
                optimal_k = np.argmax(diff_ratios) + 2  # +2 because we start from k=1 and take diff
                return min(optimal_k, max_k)
    except Exception as e:
        print(f"Warning: Could not determine optimal clusters: {e}")
    
    return 3  # Default fallback

def get_model_info():
    """
    Get information about this model
    
    Returns:
        Dictionary with model information
    """
    return {
        'name': 'K-Means Clustering',
        'type': 'unsupervised',
        'task': 'clustering',
        'description': 'K-Means partitions data into k clusters by minimizing within-cluster sum of squares.',
        'hyperparameters': {
            'n_clusters': {
                'type': 'integer',
                'default': 3,
                'range': [2, 20],
                'description': 'Number of clusters to form'
            },
            'init': {
                'type': 'string',
                'default': 'k-means++',
                'options': ['k-means++', 'random'],
                'description': 'Method for initialization'
            },
            'n_init': {
                'type': 'integer',
                'default': 10,
                'range': [5, 50],
                'description': 'Number of time the k-means algorithm will be run'
            },
            'max_iter': {
                'type': 'integer',
                'default': 300,
                'range': [100, 1000],
                'description': 'Maximum number of iterations'
            },
            'tol': {
                'type': 'float',
                'default': 1e-4,
                'range': [1e-6, 1e-2],
                'description': 'Tolerance for convergence'
            }
        },
        'pros': [
            'Simple and fast algorithm',
            'Works well with spherical clusters',
            'Scalable to large datasets',
            'Guaranteed convergence',
            'Easy to interpret results'
        ],
        'cons': [
            'Need to specify number of clusters',
            'Sensitive to initialization',
            'Assumes spherical clusters',
            'Sensitive to outliers and noise',
            'Struggles with varying cluster sizes'
        ],
        'use_cases': [
            'Customer segmentation',
            'Image segmentation',
            'Data compression',
            'Market research',
            'Preliminary data exploration'
        ]
    }
